from __future__ import unicode_literals

# noinspection PyUnresolvedReferences
from codequick import Route, Resolver, Listitem, run
from codequick.utils import urljoin_partial, bold
import requests
import xbmcgui
import re
import urllib
import inputstreamhelper
from bs4 import BeautifulSoup

base_url = "https://www3.dramacool.movie"

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.71 Safari/537.36"
}


def get_video_url(episode_url):
    regex = r"file: '(.*?)'"

    response = requests.get(episode_url, allow_redirects=True).text

    soup = BeautifulSoup(response, "html.parser")

    streaming_link = soup.select(
        "body > div.container > div > div.content-left > div.block.watch-drama > div.anime_muti_link > ul > li.kvid")[
        0].get("data-video")
    "body > div > div > script"

    response2 = requests.get(f"https:{streaming_link}", headers=headers).text
    soup2 = BeautifulSoup(response2, "html.parser")

    stream_source = soup2.select("body > div > div > script")[0]

    return re.search(regex, str(stream_source)).group(1)


@Route.register
def root(plugin, content_type="segment"):
    yield Listitem.search(search_drama)

    item = Listitem()
    item.label = "Watch Asian Drama"
    item.set_callback(list_drama, page_no=1)

    yield item


@Route.register
def list_drama(plugin, page_no):
    response = requests.get(
        f"https://www3.dramacool.movie/recently-added?page={page_no}", allow_redirects=True).text

    soup = BeautifulSoup(response, "html.parser")

    drama_images = soup.select(
        "body > div.container > div > div.content-left > div.block-tab > div > div > ul.switch-block.list-episode-item > li > a > img")

    drama_titles = soup.select(
        "body > div.container > div > div.content-left > div.block-tab > div > div > ul.switch-block.list-episode-item > li > a > h3")

    next_page = soup.select(
        "body > div.container > div > div.content-left > div.block-tab > div > div > ul.pagination > li.next > a"
    )[0].get("data-page")

    for drama_title, drama_image in zip(drama_titles, drama_images):
        item = Listitem()
        item.label = drama_title.text
        item.art["thumb"] = drama_image.get("data-original")
        item.art["fanart"] = drama_image.get("data-original")
        item.info["plot"] = f"Watch {drama_title.text}"
        item.set_callback(get_episodes, drama_url=drama_title.get(
            "onclick").replace("window.location = '", base_url).replace("'", ""),
            img_url=drama_image.get("data-original"))

        yield item
    yield Listitem.next_page(page_no=next_page, callback=list_drama)


@Route.register
def get_episodes(plugin, drama_url, img_url):
    response = requests.get(drama_url, allow_redirects=True).text

    soup = BeautifulSoup(response, "html.parser")

    episodes = soup.select(
        "body > div.container > div > div.content-left > div.block-tab > div > div > ul > li > a > h3")

    episodes_type = soup.select(
        "body > div.container > div > div.content-left > div.block-tab > div > div > ul > li > a > span.type"
    )

    for episode, e_type in zip(episodes, episodes_type):
        item = Listitem()
        item.art["thumb"] = img_url
        item.art["fanart"] = img_url
        item.label = f"{episode.text} {e_type.text}"
        item.set_callback(play_video, video_url=episode.get("onclick").replace(
            "window.location = '", base_url).replace("'", ""), v_title=f"{episode.text} {e_type.text}")
        yield item


@Route.register
def search_drama(plugin, search_query):
    response = requests.get(
        f"{base_url}/search?type=movies&keyword={search_query}").text
    soup = BeautifulSoup(response, "html.parser")

    drama_images = soup.select(
        "body > div.container > div > div.content-left > div.block-tab > div > div > ul.switch-block.list-episode-item > li > a > img")

    drama_titles = soup.select(
        "body > div.container > div > div.content-left > div.block-tab > div > div > ul.switch-block.list-episode-item > li > a > h3")

    for drama_title, drama_image in zip(drama_titles, drama_images):
        item = Listitem()
        item.label = drama_title.text
        item.art["thumb"] = drama_image.get("data-original")
        item.art["fanart"] = drama_image.get("data-original")
        item.info["plot"] = f"Watch {drama_title.text}"
        item.set_callback(get_episodes, drama_url=drama_title.get(
            "onclick").replace("window.location = '", base_url).replace("'", ""),
            img_url=drama_image.get("data-original"))

        yield item


@Resolver.register
def play_video(plugin, video_url, v_title):
    # return plugin.extract_source(get_video_url(video_url), referer="https://asianload1.com/")
    vid_url = f"{get_video_url(video_url)}|User-Agent={headers['User-Agent']}&Referer=https://asianload1.com&Origin=https://asianload1.com".strip()
    return Listitem().from_dict(**{
        "label": v_title,
        "callback": vid_url,
        "properties": {
            "inputstream.adaptive.manifest_type": "hls",
            "inputstream": "inputstream.adaptive"


        }
    })
